
import UIKit
import XCTest
import XCPlayground
import PlaygroundSupport


protocol Burstable{
    func burst()
}

class FCFS:SchedulingAlgorithm, Burstable{
    
    func burst(){
        var time:Float = 0.0
        for process in processes{
            
            timeline.append((start: time, end: time + process.duration, process: process))
            time = time + process.duration
            
        }
        
        for time in timeline{
            
            time.process.waitingTime = time.start - time.process.arrivalTime
            
        }
        self.waitingTimes = processes.map{$0.waitingTime}
        self.averageWaitingTime = self.waitingTimes!.reduce(0, +) / Float(processes.count)
    }
    
}
class SJF:SchedulingAlgorithm, Burstable{
    
    internal func burst(){
        
        processes.sort { (p1, p2) -> Bool in
            return p1.duration < p2.duration
        }
        
        let fcfs = FCFS(processes: processes)
        fcfs.burst()
        self.averageWaitingTime = fcfs.averageWaitingTime
        self.waitingTimes = fcfs.waitingTimes
    }
    
}

class SRTF:SchedulingAlgorithm, Burstable{
    
    internal func burst(){
        
        var time:Float = 0.0
        let arrivalTimes = Set(processes.map{$0.arrivalTime} + [processes.map{$0.duration}.reduce(0, +)])

//        while !(processes.filter{$0.left > 0}).isEmpty{
//
//            for process in (processes.filter{$0.left > 0}){
//
//
//
//
//                // let duration = process.left
//                process.execute(time: 2)
//            }
//
//        }
        
        
        
        self.averageWaitingTime = 7
        self.waitingTimes = []
    }
    
}
class PBS:SchedulingAlgorithm, Burstable{
    
    internal func burst(){
        
        processes.sort { (p1, p2) -> Bool in
            return p1.priority > p2.priority
        }
        
        let fcfs = FCFS(processes: processes)
        fcfs.burst()
        self.averageWaitingTime = fcfs.averageWaitingTime
        self.waitingTimes = fcfs.waitingTimes
    }
    
}

class RoundRobin:SchedulingAlgorithm, Burstable{
    
    private var quantum:Float
    
    init(processes:[Process], quantum:Float) {
        self.quantum = quantum
        super.init(processes: processes)
        
    }
    
    internal func burst(){
        var time:Float = 0.0
        while !(processes.filter{$0.left > 0}).isEmpty{
            
            for process in (processes.filter{$0.left > 0})
            {
                let duration = process.left
                process.execute(time: quantum)
                timeline.append((start: time, end: time + duration - process.left, process: process))
                time = time + duration - process.left
                
            }
            
        }
        for process in processes{
            let sameCycles = timeline.filter{$0.process.name == process.name}
            
            for (index, cycle) in sameCycles.enumerated(){
                
                process.waitingTime = process.waitingTime + cycle.start - ((index - 1) >= 0 ? sameCycles[index - 1].end : 0)
                
            }
            
        }
        
        self.waitingTimes = processes.map{$0.waitingTime}
        self.averageWaitingTime = self.waitingTimes!.reduce(0, +) / Float(processes.count)
    }
    
}


class TestedPlayground: XCTestCase {
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    func testFCFS(){
        let processes = [
            Process(name:"P1", duration: 6),
            Process(name:"P2", duration: 8),
            Process(name:"P3", duration: 7),
            Process(name:"P4", duration: 3)
        ]
        
        let fcfs = FCFS(processes: processes)
        fcfs.burst()
        fcfs.averageWaitingTime
        fcfs.waitingTimes
        
        XCTAssertEqual(10.25,  fcfs.averageWaitingTime!, accuracy: 0.001)
        XCTAssert(fcfs.waitingTimes! == [0, 6, 14, 21])
        
    }
    
    func testSJF(){
        
        let processes = [
            Process(name:"P1", duration: 6),
            Process(name:"P2", duration: 8),
            Process(name:"P3", duration: 7),
            Process(name:"P4", duration: 3)
        ]
        
        let sjf = SJF(processes: processes)
        sjf.burst()
        sjf.averageWaitingTime
        sjf.waitingTimes
        
        XCTAssertEqual(7,  sjf.averageWaitingTime!, accuracy: 0.001)
        XCTAssert(sjf.waitingTimes! == [0, 3, 9, 16])
    }
    
    func testSRTF(){
        
        let processes = [
            Process(name:"P1", duration: 8, arrivalTime:0),
            Process(name:"P2", duration: 4, arrivalTime:1),
            Process(name:"P3", duration: 9, arrivalTime:2),
            Process(name:"P4", duration: 5, arrivalTime:3)
        ]
        
        let sjf = SRTF(processes: processes)
        sjf.burst()
        sjf.averageWaitingTime
        sjf.waitingTimes
        
        XCTAssertEqual(7,  sjf.averageWaitingTime!, accuracy: 0.001)
        XCTAssert(sjf.waitingTimes! == [0, 3, 9, 16])
    }
    
    func testRR(){
        let processes = [
            Process(name:"P1", duration: 6),
            Process(name:"P2", duration: 5),
            Process(name:"P3", duration: 2),
            Process(name:"P4", duration: 3),
            Process(name:"P5", duration: 7)
        ]
        
        let rr = RoundRobin(processes: processes, quantum: 2)
        rr.burst()
        rr.averageWaitingTime
        rr.waitingTimes
        
        XCTAssertEqual(10.25,  rr.averageWaitingTime!, accuracy: 12)
        XCTAssert(rr.waitingTimes! == [13, 15, 4, 12, 16])
        
    }
    
    func testPBS(){
        let processes = [
            Process(name:"P1", duration: 5, arrivalTime:0, priority:1),
            Process(name:"P2", duration: 3, arrivalTime:1, priority:2),
            Process(name:"P3", duration: 8, arrivalTime:2, priority:1),
            Process(name:"P4", duration: 6, arrivalTime:3, priority:3)
        ]
        
        let pbs = PBS(processes: processes)
        pbs.burst()
        pbs.averageWaitingTime
        pbs.waitingTimes
        
    }
    
}


TestedPlayground.defaultTestSuite.run()

