
/*:
 
 ## CPU Scheduling Algorithms
 
 * First Come First Search **FCFS**
 * Shortest Job First **SJF**
 * Shortest-Remaining-Time-First (Preemptive SJF) **SRTF**
 * Priority Based Scheduling **PBS**
 * Round Robin **RR**
 
 */
