
extension Process:CustomStringConvertible{
    
    public var description:String{return name}
    
}

open class Process{
    public let name:String
    public let duration:Float
    public var left:Float
    public var waitingTime:Float = 0
    public var arrivalTime:Float = 0
    public var priority:Int = 0
    public func execute(time:Float){
        
        left = time >= left ? 0 : (left - time)
        
    }
    
    public init(name:String, duration:Float, arrivalTime:Float = 0, priority:Int = 1) {
        self.priority = priority
        self.name = name
        self.duration = duration
        self.left = self.duration
        self.arrivalTime = arrivalTime
    }
    
}
