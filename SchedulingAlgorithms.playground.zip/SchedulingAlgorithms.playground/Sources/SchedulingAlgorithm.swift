import Foundation

open class SchedulingAlgorithm{
    public var processes:[Process]
    public var timeline:[(start:Float, end:Float, process:Process)] = []
    public var waitingTimes:[Float]? = nil
    public var averageWaitingTime:Float? = nil
    public init(processes:[Process])
    {
        self.processes = processes
    }
}
